﻿using System.Data.Entity;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newsletter.Controllers;
using Newsletter.Persistence;
using Newsletter.Core.ViewModels;

namespace Newsletter.Tests.Controllers
{
    [TestClass]
    public class HomeControllerIntegrationTests
    {
        private HomeController _controller;
        private ApplicationDbContext _context;
        private DbContextTransaction _transaction;

        [TestInitialize]
        public void TestInitialize()
        {
            _context = new ApplicationDbContext();
            _transaction = _context.Database.BeginTransaction();

            _controller = new HomeController(new UnitOfWork(_context));
        }

        [TestCleanup]
        public void TestCleanup()
        {
            _transaction.Rollback();
            _transaction.Dispose();
            _context.Dispose();
        }

        [TestMethod]
        public void Index_WhenCalled_ShouldAddSubscriber()
        {
            var viewModel = new SubscriberViewModel()
            {
                Email = "addsubscriber@test.com",
                Referrer = 2
            };
            var result = _controller.Index(viewModel).Result;

            var newlyAddedSubscriber = _context.Subscribers.FirstOrDefaultAsync(s => s.Email == "addsubscriber@test.com").Result;
            Assert.AreEqual(viewModel.Email, newlyAddedSubscriber.Email);
        }
    }
}
