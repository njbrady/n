﻿using System.Web;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Moq;
using Newsletter.Controllers;
using Newsletter.Core;
using Newsletter.Core.Models;
using Newsletter.Core.Repositories;
using Newsletter.Core.ViewModels;

namespace Newsletter.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTests
    {
        private HomeController _controller;
        private Mock<IUnitOfWork> _mockUnitOfWork;

        [TestInitialize]
        public void TestInitialize()
        {
            _mockUnitOfWork = new Mock<IUnitOfWork>();

            var referrerMockRepository = new Mock<IReferrerRepository>();
            referrerMockRepository.Setup(r => r.GetAll()).ReturnsAsync(new Mock<List<Referrer>>().Object);
            _mockUnitOfWork.Setup(u => u.Referrers).Returns(referrerMockRepository.Object);

            _mockUnitOfWork.Setup(u => u.Subscribers).Returns(new Mock<ISubscriberRepository>().Object);

            _controller = new HomeController(_mockUnitOfWork.Object);
        }

        [TestMethod]
        public void Index_InvalidPost_MVCValidation()
        {
            _controller.ViewData.ModelState.AddModelError("Key", "Error");
            var viewModel = new SubscriberViewModel
            {
                Referrer = 1,
                Referrers = new List<Referrer>()
            };
            var result = _controller.Index(viewModel).Result as ViewResult;

            Assert.AreEqual(result.ViewData.Model, viewModel);
        }

        [TestMethod]
        public void Index_ValidRequest_RedirectToSubscribed()
        {
            _mockUnitOfWork.Setup(u => u.CompleteWithUniqueKeyValidation()).ReturnsAsync(true);

            var viewModel = new SubscriberViewModel
            {
                Email = "test@test.com",
                Referrer = 1
            };
            var result = _controller.Index(viewModel).Result as RedirectToRouteResult;

            Assert.AreEqual("Subscribed", result.RouteValues["action"]);
        }

        [TestMethod]
        public void Index_EmailExists_EmailValidation()
        {
            _mockUnitOfWork.Setup(u => u.CompleteWithUniqueKeyValidation()).ReturnsAsync(false);

            var viewModel = new SubscriberViewModel
            {
                Email = "test@test.com",
                Referrer = 1
            };
            var result = _controller.Index(viewModel).Result as ViewResult;

            Assert.IsTrue(result.ViewData.ModelState.IsValid==false&&result.ViewData.ModelState.Keys.Contains("Email"));
        }
    }
}
