﻿using System.Web.Mvc;
using System.Threading.Tasks;
using Newsletter.Core;
using Newsletter.Core.Models;
using Newsletter.Core.ViewModels;
using Newsletter.Persistence;

namespace Newsletter.Controllers
{
    public class HomeController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public HomeController()
        {
            _unitOfWork = new UnitOfWork(new ApplicationDbContext());
        }

        public HomeController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<ActionResult> Index()
        {
            var viewModel = new SubscriberViewModel
            {
                Referrers = await _unitOfWork.Referrers.GetAll(),
            };
            return View(viewModel);
        }

        [HttpPost]
        public async Task<ActionResult> Index(SubscriberViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                viewModel.Referrers = await _unitOfWork.Referrers.GetAll();
                return View(viewModel);
            }

            _unitOfWork.Subscribers.Add(new Subscriber(viewModel.Email, viewModel.Referrer, viewModel.Reason));
            bool isValidKey = await _unitOfWork.CompleteWithUniqueKeyValidation();
            if (!isValidKey)
            {
                ModelState.AddModelError("Email", "Already signed up.");
                viewModel.Referrers = await _unitOfWork.Referrers.GetAll();
                return View(viewModel);
            }

            return RedirectToAction("Subscribed");
        }

        public ActionResult Subscribed()
        {
            return View();
        }
    }
}