﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Newsletter.Core.Repositories;

namespace Newsletter.Core
{
    public interface IUnitOfWork
    {
        IReferrerRepository Referrers { get; }

        ISubscriberRepository Subscribers { get; }

        Task<bool> CompleteWithUniqueKeyValidation();
    }
}