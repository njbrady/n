﻿using System.ComponentModel.DataAnnotations;

namespace Newsletter.Core.Models
{
    public class Referrer
    {
        public byte Id { get; set; }

        [Required]
        [StringLength(255)]
        public string Name { get; set; }
    }
}