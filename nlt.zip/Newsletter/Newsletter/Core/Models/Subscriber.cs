﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Newsletter.Core.Models
{
    public class Subscriber
    {
        protected Subscriber()
        {
        }

        [Key]
        [DataType(DataType.EmailAddress)]
        public string Email { get; private set; }

        [Required]
        public byte ReferrerId { get; private set; }

        public Referrer Referrer { get; private set; }

        [StringLength(255)]
        public string Reason { get; private set; }

        public Subscriber(string email, byte referrerId, string reason)
        {
            if (email == null)
                throw new ArgumentNullException("email");

            Email = email;
            ReferrerId = referrerId;
            Reason = reason;
        }
    }
}