﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Newsletter.Core.Models;

namespace Newsletter.Core.Repositories
{
    public interface IReferrerRepository
    {
        Task<List<Referrer>> GetAll();
    }
}