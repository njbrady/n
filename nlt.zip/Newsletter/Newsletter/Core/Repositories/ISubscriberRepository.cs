﻿using Newsletter.Core.Models;

namespace Newsletter.Core.Repositories
{
    public interface ISubscriberRepository
    {
        void Add(Subscriber subscriber);
    }
}