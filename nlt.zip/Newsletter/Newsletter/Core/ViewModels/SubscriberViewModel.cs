﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newsletter.Core.Models;

namespace Newsletter.Core.ViewModels
{
    public class SubscriberViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public byte Referrer { get; set; }

        [StringLength(255)]
        public string Reason { get; set; }

        public IEnumerable<Referrer> Referrers { get; set; }
    }
}