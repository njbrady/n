﻿using System.Data.Entity;
using Newsletter.Core.Models;

namespace Newsletter.Persistence
{
    public class ApplicationDbContext : DbContext, IApplicationDbContext
    {
        public DbSet<Subscriber> Subscribers { get; set; }
        public DbSet<Referrer> Referrers { get; set; }

        public ApplicationDbContext()
        {
        }
    }
}