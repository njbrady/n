﻿using System.Data.Entity;
using Newsletter.Core.Models;

namespace Newsletter.Persistence
{
    interface IApplicationDbContext
    {
        DbSet<Subscriber> Subscribers { get; set; }
        DbSet<Referrer> Referrers { get; set; }
    }
}
