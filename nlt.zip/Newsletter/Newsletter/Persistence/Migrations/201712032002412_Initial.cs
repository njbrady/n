namespace Newsletter.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Referrers",
                c => new
                    {
                        Id = c.Byte(nullable: false),
                        Name = c.String(nullable: false, maxLength: 255),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Subscribers",
                c => new
                    {
                        Email = c.String(nullable: false, maxLength: 128),
                        ReferrerId = c.Byte(nullable: false),
                        Reason = c.String(maxLength: 255),
                    })
                .PrimaryKey(t => t.Email)
                .ForeignKey("dbo.Referrers", t => t.ReferrerId)
                .Index(t => t.ReferrerId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Subscribers", "ReferrerId", "dbo.Referrers");
            DropIndex("dbo.Subscribers", new[] { "ReferrerId" });
            DropTable("dbo.Subscribers");
            DropTable("dbo.Referrers");
        }
    }
}
