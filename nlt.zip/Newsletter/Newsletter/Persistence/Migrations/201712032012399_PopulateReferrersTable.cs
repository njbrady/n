namespace Newsletter.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PopulateReferrersTable : DbMigration
    {
        public override void Up()
        {
            Sql("INSERT INTO Referrers (Id, Name) VALUES (1, 'Advert')");
            Sql("INSERT INTO Referrers (Id, Name) VALUES (2, 'Word of Mouth')");
            Sql("INSERT INTO Referrers (Id, Name) VALUES (3, 'Other')");
        }
        
        public override void Down()
        {
            Sql("DELETE FROM Genres WHERE Id IN (1, 2, 3)");
        }
    }
}
