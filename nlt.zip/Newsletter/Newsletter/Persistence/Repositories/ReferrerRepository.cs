﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data.Entity;
using Newsletter.Core.Models;
using Newsletter.Core.Repositories;

namespace Newsletter.Persistence.Repositories
{
    public class ReferrerRepository : IReferrerRepository
    {
        private ApplicationDbContext _context;

        public ReferrerRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Referrer>> GetAll()
        {
            return await _context.Referrers.ToListAsync();
        }
    }
}