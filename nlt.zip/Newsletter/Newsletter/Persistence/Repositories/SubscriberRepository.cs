﻿using Newsletter.Core.Models;
using Newsletter.Core.Repositories;

namespace Newsletter.Persistence.Repositories
{
    public class SubscriberRepository : ISubscriberRepository
    {
        private ApplicationDbContext _context;

        public SubscriberRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Add(Subscriber subscriber)
        {
            _context.Subscribers.Add(subscriber);
        }
    }
}