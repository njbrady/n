﻿using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Entity.Infrastructure;
using Newsletter.Core;
using Newsletter.Core.Repositories;
using Newsletter.Persistence.Repositories;

namespace Newsletter.Persistence
{
    public class UnitOfWork : IUnitOfWork
    {
        private ApplicationDbContext _context;

        public UnitOfWork(ApplicationDbContext context)
        {
            _context = context;

            Referrers = new ReferrerRepository(_context);
            Subscribers = new SubscriberRepository(_context);
        }

        public IReferrerRepository Referrers { get; private set; }

        public ISubscriberRepository Subscribers { get; private set; }

        public async Task<bool> CompleteWithUniqueKeyValidation()
        {
            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateException exception)
            {
                var innerException = exception.InnerException.InnerException as SqlException;
                if (innerException != null && (innerException.Number == 2627 || innerException.Number == 2601))
                {
                    return false;
                }
                else
                {
                    throw;
                }
            }
        }
    }
}